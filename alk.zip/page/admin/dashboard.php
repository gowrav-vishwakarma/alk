<?php

class page_admin_dashboard extends page_admin {
	function init(){
		parent::init();
		
	}
}