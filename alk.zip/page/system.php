<?php

class page_system extends Page {
	function init(){
		parent::init();
		// $this->api->redirect('user_dashboard');
	}
}