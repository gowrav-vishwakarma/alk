<?php
class Form_Field_image extends Form_Field_upload {
}
