<?php
class Controller_SNI extends AbstractController {
}
