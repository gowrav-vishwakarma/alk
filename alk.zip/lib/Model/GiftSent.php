<?php

class Model_GiftSent extends Model_Gift{} 