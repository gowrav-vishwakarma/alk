<?php

class Model_PinPurchaseExpense extends Model_PinPurchaseRequest{}