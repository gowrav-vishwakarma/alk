<?php

class Model_PinPurchaseIncome extends Model_PinPurchaseRequest{}