<?php

class Model_GiftReceived extends Model_Gift{}